const express = require('express');
const cors = require('cors');
const { createClient } = require('@supabase/supabase-js');
const axios = require('axios');
const cheerio = require('cheerio');
const { GoogleGenerativeAI } = require('@google/generative-ai');
const path = require('path');
const {
    importOfficialCandidates,
    deleteCandidatesFromOtherYears,
    importOfficialCandidatePhotos,
    PHOTO_BUCKET
} = require('./candidatos.js');
require('dotenv').config({ path: path.join(__dirname, '../env/supabase.env') });
 
function requiredEnv(name) {
    const value = process.env[name];
    if (!value) {
        throw new Error(`Variável de ambiente obrigatória ausente: ${name}`);
    }
    return value;
}
 
const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../frontend')));
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '../frontend/paginainicial.html'));
});
 
// Inicialização do Supabase
const supabaseUrl = requiredEnv('SUPABASE_URL');
const supabaseKey = requiredEnv('SUPABASE_SERVICE_ROLE_KEY');
const supabase = createClient(supabaseUrl, supabaseKey);
let partidosCandidatosCache = { expiresAt: 0, values: [] };
const newsReadSource = 'pesquisas_politicas';
const gemini = process.env.GEMINI_API_KEY
    ? new GoogleGenerativeAI(process.env.GEMINI_API_KEY)
    : null;
// Modelos válidos em diferentes contas e regiões da API do Gemini. Google
// remove modelos antigos com frequência, então a lista de fallback precisa
// usar nomes atuais para evitar 404 e falhas constantes.
const GEMINI_MODELS_FALLBACK = [
    'gemini-3.8-flash',
    'gemini-3.5-flash',
    'gemini-2.5-pro'
];
const geminiModel = process.env.GEMINI_MODEL || GEMINI_MODELS_FALLBACK[0];
const OFFICIAL_SOURCES = [
    'gov.br',
    'camara.leg.br',
    'senado.leg.br',
    'al.es.gov.br',
    'es.gov.br',
    'tjes.jus.br',
    'mpes.mp.br',
    'planalto.gov.br',
    'agenciabrasil.ebc.com.br'
];
const FACT_CHECK_SITES = [
    'Aos Fatos',
    'Lupa',
    'Polígrafo',
    'Estadão Verifica',
    'UOL Confere',
    'Agência Brasil'
];
const FACT_CHECK_URLS = [
    'https://www.aosfatos.org/',
    'https://piaui.folha.uol.com.br/lupa/',
    'https://www.politifact.com/',
    'https://www.estadao.com.br/infograficos/verifica/'
];

const PORT = process.env.PORT || 3010;
const CANDIDATOS_ELEICAO_ANO = 2026;
const SUMMARY_BATCH_SIZE = Math.max(1, Number(process.env.SUMMARY_BATCH_SIZE || 2));
const SUMMARY_BATCH_DELAY_MS = Math.max(0, Number(process.env.SUMMARY_BATCH_DELAY_MS || 30000));

// Feed já pré-filtrado pelo Google News para política + Espírito Santo.
// Isso reduz o volume de itens irrelevantes antes mesmo do filtro local.
const newsFeedUrl = 'https://news.google.com/rss/search?q=politica+%22Esp%C3%ADrito+Santo%22&hl=pt-BR&gl=BR&ceid=BR:pt-419';
 
const fallbackNews = [
    {
        titulo: 'Assembleia Legislativa do Espírito Santo aprova novas regras de transparência',
        url: 'https://www.al.es.gov.br/noticia/exemplo',
        snippet: 'ALES aprova projeto que amplia transparência sobre emendas parlamentares no estado.',
        categoria: 'deputado',
        partido: 'Geral',
        data_publicacao: '2026-06-01',
        imagem_url: null
    },
    {
        titulo: 'Governo do Espírito Santo anuncia medidas econômicas para o estado',
        url: 'https://www.es.gov.br/noticia/exemplo',
        snippet: 'Governador destaca avanços econômicos e metas fiscais para o segundo semestre no ES.',
        categoria: 'governador',
        partido: 'Executivo',
        data_publicacao: '2026-06-02',
        imagem_url: null
    }
];
 
// ---------------------------------------------------------------------------
// FILTRAGEM E CLASSIFICAÇÃO DE CONTEÚDO POLÍTICO
// ---------------------------------------------------------------------------
 
const POLITICAL_KEYWORDS = [
    'política', 'politica', 'governo', 'congresso', 'câmara', 'camara',
    'senado', 'deputado', 'senador', 'ministro', 'ministério', 'ministerio',
    'presidente', 'presidência', 'presidencia', 'planalto', 'eleição', 'eleicao',
    'eleições', 'eleicoes', 'partido', 'votação', 'votacao', 'projeto de lei',
    'plenário', 'plenario', 'stf', 'tse', 'governador', 'prefeito', 'vereador',
    'reforma', 'oposição', 'oposicao', 'base aliada', 'gabinete', 'coligação',
    'coligacao', 'cpi', 'impeachment'
];
 
// ---------------------------------------------------------------------------
// FILTRO GEOGRÁFICO: ESPÍRITO SANTO
// ---------------------------------------------------------------------------
// Termos que indicam que a notícia é sobre o estado do Espírito Santo:
// o nome do estado, sigla em contexto claro, a assembleia legislativa
// estadual (ALES) e os principais municípios capixabas. Uma notícia só
// é aceita se contiver política E algum desses termos.
const ES_KEYWORDS = [
    'espírito santo', 'espirito santo', 'capixaba', 'capixabas',
    'ales', 'assembleia legislativa do espírito santo', 'assembleia legislativa do espirito santo',
    'governo do estado do espírito santo', 'governo do estado do espirito santo',
    'vitória', 'vitoria-es', 'vila velha', 'serra-es', 'cariacica',
    'cachoeiro de itapemirim', 'linhares', 'colatina', 'guarapari',
    'aracruz', 'ibiraçu', 'ibiracu', 'são mateus', 'sao mateus',
    'nova venécia', 'nova venecia', 'barra de são francisco', 'barra de sao francisco',
    'viana-es', 'marataízes', 'marataizes', 'piúma', 'piuma', 'anchieta-es',
    'domingos martins', 'santa teresa-es', 'santa maria de jetibá', 'santa maria de jetiba',
    'grande vitória', 'grande vitoria'
];
 
const CATEGORY_RULES = [
    { categoria: 'presidente', termos: ['presidente', 'presidência', 'presidencia', 'planalto'] },
    { categoria: 'ministro', termos: ['ministro', 'ministra', 'ministério', 'ministerio'] },
    { categoria: 'senador', termos: ['senador', 'senadora', 'senado federal'] },
    { categoria: 'deputado', termos: [
        'deputado', 'deputada', 'câmara dos deputados', 'camara dos deputados',
        'ales', 'assembleia legislativa do espírito santo', 'assembleia legislativa do espirito santo',
        'deputado estadual', 'deputada estadual'
    ] },
    { categoria: 'governador', termos: ['governador', 'governadora', 'governo estadual', 'governo do espírito santo', 'governo do espirito santo'] },
    { categoria: 'prefeito', termos: ['prefeito', 'prefeita', 'prefeitura', 'vereador', 'vereadora'] },
    { categoria: 'judiciario', termos: ['stf', 'supremo tribunal', 'tse', 'tribunal', 'ministro do stf', 'tjes', 'tribunal de justiça do espírito santo'] },
    { categoria: 'eleicoes', termos: ['eleição', 'eleicao', 'eleições', 'eleicoes', 'candidato', 'candidata', 'urna', 'votação', 'votacao'] }
];
 
const PARTY_LIST = [
    'PT', 'PL', 'PSDB', 'MDB', 'PP', 'REPUBLICANOS', 'PSOL', 'PDT', 'PSD',
    'UNIÃO BRASIL', 'UNIAO BRASIL', 'NOVO', 'PCDOB', 'PSB', 'PODEMOS',
    'CIDADANIA', 'AVANTE', 'SOLIDARIEDADE', 'PROS', 'PATRIOTA', 'PV', 'REDE'
];
 
function isPoliticalContent(text) {
    const normalized = text.toLowerCase();
    return POLITICAL_KEYWORDS.some((termo) => normalized.includes(termo));
}
 
// Retorna true se o texto menciona o Espírito Santo (estado, sigla em
// contexto claro, ALES ou algum dos principais municípios capixabas).
function isEspiritoSantoContent(text) {
    const normalized = text.toLowerCase();
    return ES_KEYWORDS.some((termo) => normalized.includes(termo));
}
 
function classifyCategoria(text) {
    const normalized = text.toLowerCase();
    for (const rule of CATEGORY_RULES) {
        if (rule.termos.some((termo) => normalized.includes(termo))) {
            return rule.categoria;
        }
    }
    return 'geral';
}
 
function classifyPartido(text) {
    const upper = text.toUpperCase();
    const encontrados = PARTY_LIST.filter((sigla) => {
        const escaped = sigla.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        const regex = new RegExp(`(^|[^A-ZÀ-Ú])${escaped}([^A-ZÀ-Ú]|$)`);
        return regex.test(upper);
    });
    return encontrados.length > 0 ? encontrados.join(', ') : 'Geral';
}
 
// ---------------------------------------------------------------------------
// EXTRAÇÃO DE IMAGEM DA NOTÍCIA
// ---------------------------------------------------------------------------
 
// Busca a imagem principal de uma página de notícia: primeiro tenta as meta
// tags padrão (og:image / twitter:image), que é onde praticamente todo site
// de notícia declara a imagem de capa do artigo. Se não achar, cai para a
// primeira <img> dentro de <article> e, por último, a primeira <img> da página.
async function extractArticleImage(url) {
    try {
        const response = await axios.get(url, {
            timeout: 8000,
            maxRedirects: 5,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) SPP/1.0 NewsBot'
            }
        });
 
        // URL final após seguir redirecionamentos (importante para o link do
        // Google News, que costuma redirecionar para o site de origem).
        const finalUrl = response.request?.res?.responseUrl || url;
        const $ = cheerio.load(response.data);
 
        const imageSrc =
            $('meta[property="og:image"]').attr('content') ||
            $('meta[property="og:image:secure_url"]').attr('content') ||
            $('meta[name="twitter:image"]').attr('content') ||
            $('meta[name="twitter:image:src"]').attr('content') ||
            $('article img').first().attr('src') ||
            $('img').first().attr('src');
 
        if (!imageSrc) return null;
 
        // Resolve URLs relativas (ex.: "/imagens/foto.jpg") para absolutas
        return new URL(imageSrc, finalUrl).href;
    } catch (error) {
        console.error(`Não foi possível extrair imagem de ${url}: ${error.message}`);
        return null;
    }
}
 
// Limitador de concorrência simples (sem dependência extra tipo p-limit):
// processa a lista em paralelo, mas no máximo `limit` requisições por vez,
// pra não abrir 30 conexões simultâneas e não tomar rate-limit dos sites.
async function mapWithConcurrency(items, limit, worker) {
    let index = 0;
 
    async function run() {
        while (index < items.length) {
            const current = index++;
            await worker(items[current], current);
        }
    }
 
    const workers = Array.from({ length: Math.min(limit, items.length) }, run);
    await Promise.all(workers);
}
 
// ---------------------------------------------------------------------------
// RESUMO DA NOTÍCIA
// ---------------------------------------------------------------------------
 
// Busca um resumo da notícia direto na página de origem: primeiro tenta a
// meta description / og:description (o próprio site já resume a matéria),
// e se não achar, cai para os primeiros parágrafos do corpo do texto.
async function extractArticleSummary(url) {
    try {
        const response = await axios.get(url, {
            timeout: 8000,
            maxRedirects: 5,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) SPP/1.0 NewsBot'
            }
        });
        const $ = cheerio.load(response.data);
 
        let resumo =
            $('meta[name="description"]').attr('content') ||
            $('meta[property="og:description"]').attr('content');
 
        if (!resumo || resumo.trim().length < 40) {
            const paragrafos = $('article p, .post-content p, .entry-content p, p')
                .map((_, el) => $(el).text().trim())
                .get()
                .filter((t) => t.length > 40);
            resumo = paragrafos.slice(0, 3).join(' ');
        }
 
        if (!resumo) return null;
 
        // Limita o tamanho para não guardar textos gigantes no banco
        return resumo.trim().slice(0, 600);
    } catch (error) {
        console.error(`Não foi possível extrair resumo de ${url}: ${error.message}`);
        return null;
    }
}

async function fetchTextFromUrl(url, maxLength = 1800) {
    try {
        const response = await axios.get(url, {
            timeout: 10000,
            maxRedirects: 5,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) SPP/1.0 CheckBot'
            }
        });

        const $ = cheerio.load(response.data);
        const text = $('body').text().replace(/\s+/g, ' ').trim();
        if (!text) return null;
        return text.slice(0, maxLength);
    } catch (error) {
        return null;
    }
}

function getOfficialCandidates(titulo) {
    const lower = (titulo || '').toLowerCase();
    const candidates = [];

    if (/(governo|governador|estado|espírito santo|espirito santo)/.test(lower)) {
        candidates.push('https://www.es.gov.br/', 'https://www.gov.br/');
    }
    if (/(deputado|senador|assembleia|camara|câmara)/.test(lower)) {
        candidates.push('https://www.camara.leg.br/', 'https://www.senado.leg.br/', 'https://www.al.es.gov.br/');
    }
    if (/(presidente|planalto|ministro|governo federal)/.test(lower)) {
        candidates.push('https://www.gov.br/', 'https://www.planalto.gov.br/');
    }

    return [...new Set(candidates)];
}

async function buildVerificationContext(titulo, url, conteudo) {
    const infos = [];
    const articleText = conteudo || '';
    if (articleText) infos.push(`Texto da notícia: ${articleText.slice(0, 1800)}`);

    const candidateUrls = [...new Set([url, ...getOfficialCandidates(titulo), ...FACT_CHECK_URLS])];
    for (const candidate of candidateUrls) {
        if (!candidate || candidate === url && !candidate.startsWith('http')) continue;

        const text = await fetchTextFromUrl(candidate, 1200);
        if (text) {
            infos.push(`Fonte relacionada (${candidate}): ${text}`);
            if (infos.length >= 3) break;
        }
    }

    return infos.join('\n\n');
}

async function generateSummaryWithAI(titulo, conteudo) {
    if (!gemini || !conteudo) return null;

    // Lista de modelos a tentar: primeiro o configurado (GEMINI_MODEL ou o padrão)
    // e depois uma lista de respaldo por si a Google retira o modelo.
    const modelos = [...new Set([geminiModel, ...GEMINI_MODELS_FALLBACK])];

    for (const modelo of modelos) {
        try {
            const model = gemini.getGenerativeModel({ model: modelo });
            const verificationContext = await buildVerificationContext(titulo, '', conteudo);
            const resposta = await model.generateContent(
                `Você é um assistente de resumo jornalístico em português brasileiro. Produza um texto objetivo, neutro e útil para o usuário.\n\nINSTRUÇÕES:\n1) Escreva um resumo em no máximo 4 frases, sem exageros e sem linguagem sensacionalista.\n2) Foque no fato principal, no contexto relevante e na informação que a pessoa precisa saber.\n3) Quando houver suporte em fontes oficiais ou em reportagens confiáveis, destaque essa confirmação de forma discreta, sem transformar o resumo em avaliação de veracidade.\n4) Se não houver confirmação suficiente, mantenha o texto objetivo e evite afirmar com certeza aquilo que ainda está em disputa.\n5) Não invente fatos nem use termos alarmistas.\n6) Mantenha um tom profissional e claro.\n\nContexto de apoio:\n${verificationContext}\n\nTítulo: ${titulo}\n\nConteúdo: ${conteudo}`
            );

            const texto = (resposta?.response?.text?.() || '').trim();
            if (texto) return texto;
        } catch (error) {
            console.error(`Gemini com modelo "${modelo}" falhou: ${error.message}`);
        }
    }

    console.error('Não foi possível gerar resumo com Gemini (quota, modelo indisponível ou API indisponível).');
    return null;
}
 
// ---------------------------------------------------------------------------
 
async function ingestNews() {
    let news = [];
 
    try {
        const response = await axios.get(newsFeedUrl, {
            timeout: 10000,
            headers: { 'User-Agent': 'SPP/1.0' }
        });
        const $ = cheerio.load(response.data, { xmlMode: true });
 
        $('item').slice(0, 30).each((index, element) => {
            const title = $(element).find('title').first().text().trim();
            const url = $(element).find('link').first().text().trim();
            const snippet = $(element).find('description').first().text().trim();
            const publishedAt = $(element).find('pubDate').first().text().trim();
            const date = publishedAt ? new Date(publishedAt) : new Date();
            const fullText = `${title} ${snippet}`;
 
            // Só entra se for conteúdo político E mencionar o Espírito Santo.
            if (!title || !url || !isPoliticalContent(fullText) || !isEspiritoSantoContent(fullText)) {
                return;
            }
 
            news.push({
                titulo: title,
                url,
                snippet: snippet || title,
                categoria: classifyCategoria(fullText),
                partido: classifyPartido(fullText),
                data_publicacao: Number.isNaN(date.getTime()) ? new Date().toISOString().slice(0, 10) : date.toISOString().slice(0, 10),
                imagem_url: null
            });
        });
    } catch (error) {
        console.error('Não foi possível ler o RSS de notícias:', error.message);
    }
 
    const records = news.length > 0 ? news : fallbackNews;
 
    async function processSummaryBatch(batch) {
        await Promise.all(batch.map(async (item) => {
            item.imagem_url = await extractArticleImage(item.url);

            try {
                const resumoExtraido = await extractArticleSummary(item.url);
                const textoBase = `${item.snippet || ''}\n${resumoExtraido || ''}`.trim();
                const resumoIA = textoBase ? await generateSummaryWithAI(item.titulo || '', textoBase) : null;
                item.resumo = resumoIA || resumoExtraido || item.snippet || null;
            } catch (err) {
                console.error(`Não foi possível gerar resumo para ${item.url}: ${err.message}`);
                item.resumo = item.snippet || null;
            }
        }));
    }

    // Gera os resumos em lotes pequenos para respeitar os limites da API do Gemini
    // sem tentar processar todas as notícias de uma vez.
    for (let start = 0; start < records.length; start += SUMMARY_BATCH_SIZE) {
        const batch = records.slice(start, start + SUMMARY_BATCH_SIZE);
        const endsAt = Math.min(start + SUMMARY_BATCH_SIZE, records.length);
        console.log(`Gerando resumos: ${start + 1}-${endsAt} de ${records.length}`);
        await processSummaryBatch(batch);

        if (start + SUMMARY_BATCH_SIZE < records.length && SUMMARY_BATCH_DELAY_MS > 0) {
            await new Promise((resolve) => setTimeout(resolve, SUMMARY_BATCH_DELAY_MS));
        }
    }

    const { error } = await supabase
        .from('pesquisas_politicas')
        .upsert(records, { onConflict: 'url' });

    if (error) throw error;
    return records.length;
}
 
// Rota de Ingestão e Processamento (Scraper -> JSON -> Supabase)
app.post('/api/ingest', async (req, res) => {
    try {
        const count = await ingestNews();
        res.json({ success: true, message: 'Notícias processadas e salvas com sucesso!', count });
    } catch (err) {
        console.error(err);
        res.status(500).json({ success: false, error: err.message });
    }
});

app.get('/api/candidatos/partidos', async (req, res) => {
    if (partidosCandidatosCache.expiresAt > Date.now()) {
        return res.json({ partidos: partidosCandidatosCache.values });
    }

    try {
        const partidos = new Set();
        const pageSize = 1000;
        let offset = 0;

        while (true) {
            const { data, error } = await supabase
                .from('candidatos')
                .select('partido')
                .eq('estado', 'ES')
                .order('partido', { ascending: true })
                .range(offset, offset + pageSize - 1);

            if (error) throw error;
            for (const record of data || []) {
                if (record.partido) partidos.add(record.partido);
            }
            if (!data || data.length < pageSize) break;
            offset += pageSize;
        }

        const values = [...partidos].sort((a, b) => a.localeCompare(b, 'pt-BR'));
        partidosCandidatosCache = { expiresAt: Date.now() + 10 * 60 * 1000, values };
        res.json({ partidos: values });
    } catch (error) {
        console.error('Erro ao carregar partidos dos candidatos:', error.message);
        res.status(500).json({ error: 'Não foi possível carregar os partidos dos candidatos.' });
    }
});

app.get('/api/candidatos', async (req, res) => {
    const busca = String(req.query.q || '').trim();
    const cargo = String(req.query.cargo || '').trim();
    const partido = String(req.query.partido || '').trim();
    const ano = String(req.query.ano || '').trim();
    const limite = Math.min(50, Math.max(1, Number.parseInt(req.query.limit, 10) || 20));
    const offset = Math.max(0, Number.parseInt(req.query.offset, 10) || 0);

    try {
        const consultarCandidatos = (incluirImagem) => {
            let query = supabase
                .from('candidatos')
                .select(
                    incluirImagem
                        ? 'id_tse, nome, nome_urna, partido, cargo, numero, ano, municipio, estado, situacao, imagem_url'
                        : 'id_tse, nome, nome_urna, partido, cargo, numero, ano, municipio, estado, situacao',
                    { count: 'exact' }
                )
                .eq('estado', 'ES')
                .order('ano', { ascending: false })
                .order('nome_urna', { ascending: true })
                .range(offset, offset + limite - 1);

            if (busca) query = query.ilike('nome_urna', `%${busca}%`);
            if (cargo) query = query.eq('cargo', cargo);
            if (partido) query = query.eq('partido', partido);
            if (/^\d{4}$/.test(ano)) query = query.eq('ano', Number(ano));
            return query;
        };

        let { data, count, error } = await consultarCandidatos(true);

        if (error) {
            const colunaImagemAusente = error.code === 'PGRST204'
                || error.code === '42703'
                || /column .*imagem_url.* does not exist/i.test(error.message || '');
            if (colunaImagemAusente) {
                console.warn('A coluna candidatos.imagem_url não existe; retornando candidatos sem fotos.');
                ({ data, count, error } = await consultarCandidatos(false));
            }
        }

        if (error) {
            const tabelaAusente = error.code === 'PGRST205';
            if (tabelaAusente) {
                return res.json({ total: 0, resultados: [] });
            }
            throw error;
        }

        const resultados = (data || []).map((candidate) => {
            const candidateYear = Number.isInteger(candidate.ano) ? candidate.ano : CANDIDATOS_ELEICAO_ANO;
            return {
                ...candidate,
                imagem_url: candidate.imagem_url || supabase.storage
                    .from(PHOTO_BUCKET)
                    .getPublicUrl(`${candidateYear}/${candidate.id_tse}.jpg`).data.publicUrl
            };
        });
        res.json({ total: count || data.length || 0, resultados });
    } catch (error) {
        console.error('Erro ao buscar candidaturas:', error.message);
        const tabelaAusente = error.code === 'PGRST205';
        res.status(tabelaAusente ? 503 : 500).json({
            error: tabelaAusente
                ? 'A tabela de candidatos ainda não existe. Execute dados/schema-candidatos.sql no Supabase.'
                : 'Não foi possível consultar os candidatos.'
        });
    }
});

app.get('/api/candidatos/:id', async (req, res) => {
    const idTse = String(req.params.id || '').trim();
    if (!/^\d{1,30}$/.test(idTse)) {
        return res.status(400).json({ error: 'Identificador de candidato inválido.' });
    }

    try {
        const { data, error } = await supabase
            .from('candidatos')
            .select('id_tse, nome, nome_urna, partido, cargo, numero, ano, municipio, estado, situacao, imagem_url, data_nascimento, naturalidade, atividade_profissional, cargos_anteriores, patrimonio_declarado')
            .eq('id_tse', idTse)
            .eq('estado', 'ES')
            .eq('ano', CANDIDATOS_ELEICAO_ANO)
            .maybeSingle();

        if (error) throw error;
        if (!data) return res.status(404).json({ error: 'Candidato não encontrado.' });

        const candidateYear = Number.isInteger(data.ano) ? data.ano : CANDIDATOS_ELEICAO_ANO;
        res.json({
            candidato: {
                ...data,
                imagem_url: data.imagem_url || supabase.storage
                    .from(PHOTO_BUCKET)
                    .getPublicUrl(`${candidateYear}/${data.id_tse}.jpg`).data.publicUrl
            }
        });
    } catch (error) {
        console.error('Erro ao carregar perfil do candidato:', error.message);
        res.status(500).json({
            error: error.code === 'PGRST204'
                || error.code === '42703'
                || /column .* does not exist/i.test(error.message || '')
                ? 'Os detalhes dos candidatos ainda não foram configurados. Execute novamente dados/schema-candidatos.sql no Supabase.'
                : 'Não foi possível carregar o perfil do candidato.'
        });
    }
});
 
// Rota da SERP (Search Engine Results Page) com Filtros e Busca Textual
app.get('/api/search', async (req, res) => {
    const startTime = Date.now();
    const ordemSolicitada = req.query.ordenacao || 'data';
    const ordenacao = ['data', 'data_antiga'].includes(ordemSolicitada) ? ordemSolicitada : 'data';
    const limit = Math.max(1, Number(req.query.limit || 10));
    const offset = Math.max(0, Number(req.query.offset || 0));
    const { q = '' } = req.query;
    const dia = /^\d{1,2}$/.test(String(req.query.dia || '')) ? Number(req.query.dia) : null;
    const mes = /^\d{1,2}$/.test(String(req.query.mes || '')) ? Number(req.query.mes) : null;
    const ano = /^\d{4}$/.test(String(req.query.ano || '')) ? Number(req.query.ano) : null;
 
    try {
        let query = supabase
            .from(newsReadSource)
            .select('*', { count: 'exact' });
 
        if (q.trim() !== '') {
            query = query.or(`titulo.ilike.%${q}%,snippet.ilike.%${q}%`);
        }
 
        query = query.order('data_publicacao', { ascending: ordenacao === 'data_antiga' });
 
        // Registros antigos também precisam respeitar o recorte do Espírito Santo.
        // A filtragem acontece antes do limite para não devolver menos resultados
        // quando houver notícias de outras localidades no banco.
        query = query.limit(1000);
 
        const { data: fetchedData, error } = await query;
 
        if (error) throw error;
 
        const temFiltroDeData = dia !== null || mes !== null || ano !== null;
        const filteredData = (fetchedData || []).filter((item) => {
            const textoNoticia = `${item.titulo || ''} ${item.snippet || ''}`;
            if (!isEspiritoSantoContent(textoNoticia)) return false;
            if (!temFiltroDeData) return true;

            const dateParts = String(item.data_publicacao || '').slice(0, 10).split('-').map(Number);
            if (dateParts.length !== 3 || dateParts.some((part) => !Number.isInteger(part))) return false;
            const [itemYear, itemMonth, itemDay] = dateParts;
            return (dia === null || itemDay === dia)
                && (mes === null || itemMonth === mes)
                && (ano === null || itemYear === ano);
        });

        const total = filteredData.length;
        const resultados = filteredData.slice(offset, offset + limit);
        const hasMore = offset + resultados.length < total;

        const endTime = Date.now();
        const duration = (endTime - startTime) / 1000;
 
        res.json({
            total,
            hasMore,
            limit,
            offset,
            tempoBusca: `${duration.toFixed(3)} segundos`,
            resultados
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "Erro ao realizar a busca no banco de dados." });
    }
});
 
// Rota do botão "Saiba mais":
// 1) Se a notícia já tem resumo salvo no Supabase, devolve na hora (cache).
// 2) Se não tem, busca no site de origem, salva no banco e devolve.
app.get('/api/noticias/:id/resumo', async (req, res) => {
    const { id } = req.params;
 
    try {
        const { data: noticia, error } = await supabase
            .from(newsReadSource)
            .select('id, url, titulo, snippet, resumo')
            .eq('id', id)
            .single();
 
        if (error || !noticia) {
            return res.status(404).json({ erro: 'Notícia não encontrada' });
        }
 
        if (noticia.resumo) {
            return res.json({ resumo: noticia.resumo, origem: 'cache' });
        }
 
        const resumoExtraido = await extractArticleSummary(noticia.url);
 
        if (!resumoExtraido) {
            return res.status(422).json({ erro: 'Não foi possível gerar um resumo para essa notícia' });
        }

        const resumoIA = await generateSummaryWithAI(
            noticia.titulo || '',
            `${noticia.snippet || ''}\n${resumoExtraido}`
        );
        const resumo = resumoIA || resumoExtraido;
 
        const { error: updateError } = await supabase
            .from('pesquisas_politicas')
            .update({ resumo, resumo_atualizado_em: new Date().toISOString() })
            .eq('id', id);
 
        if (updateError) throw updateError;
 
        res.json({ resumo, origem: resumoIA ? 'ia' : 'site' });
    } catch (err) {
        console.error('Erro ao gerar resumo:', err.message);
        res.status(500).json({ erro: 'Erro ao gerar resumo' });
    }
});
 
async function ensureCandidateSeed() {
    try {
        const { data: completedImport, error: importStatusError } = await supabase
            .from('candidatos_importacoes')
            .select('chave')
            .eq('chave', 'perfil-candidatos-2026-v1')
            .maybeSingle();

        if (importStatusError) throw importStatusError;
        if (completedImport) return;

        await importOfficialCandidates(CANDIDATOS_ELEICAO_ANO);
        await deleteCandidatesFromOtherYears(CANDIDATOS_ELEICAO_ANO);
        await importOfficialCandidatePhotos(CANDIDATOS_ELEICAO_ANO);

        const { error: saveStatusError } = await supabase
            .from('candidatos_importacoes')
            .upsert({ chave: 'perfil-candidatos-2026-v1', atualizado_em: new Date().toISOString() });
        if (saveStatusError) throw saveStatusError;
    } catch (error) {
        console.error('Falha ao semear candidatos:', error.message);
    }
}

async function startServer() {
    app.listen(PORT, () => {
        console.log(`Servidor rodando na porta ${PORT}`);
    });

    try {
        await ensureCandidateSeed();
        const count = await ingestNews();
        console.log(`${count} notícias carregadas automaticamente.`);
    } catch (error) {
        console.error('Falha na ingestão automática:', error.message);
    }
}

startServer();