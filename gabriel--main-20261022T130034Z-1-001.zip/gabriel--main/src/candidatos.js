/*
  Importa candidaturas de uma fonte pública e autorizada, como os dados
  abertos do TSE, filtrando os registros do Espírito Santo.

  Colunas reconhecidas incluem SQ_CANDIDATO, NM_CANDIDATO,
  NM_URNA_CANDIDATO, SG_PARTIDO, DS_CARGO, NR_CANDIDATO, ANO_ELEICAO,
  SG_UF, NM_UE e urlFoto (URL de foto oficial do TSE).
  Com --save, urlFoto/fotoUrl é copiada para o bucket público fotos-candidatos
  no Supabase Storage e o endereço público é gravado em imagem_url.

  Uso:
    node src/candidatos.js --input ./dados/candidatos-es.csv
    node src/candidatos.js --input ./dados/candidatos-es.csv --output ./dados/candidatos-filtrados.json
    node src/candidatos.js --input ./dados/candidatos-es.csv --save
    node src/candidatos.js --photos
*/

const fs = require('fs');
const path = require('path');
const os = require('os');
const yauzl = require('yauzl');
const { Readable } = require('stream');
const readline = require('readline');
const { pipeline } = require('stream/promises');
const { TextDecoder } = require('util');
const iconv = require('iconv-lite');
const { createClient } = require('@supabase/supabase-js');
require('dotenv').config({ path: path.join(__dirname, '../env/supabase.env') });

const SUPABASE_TABLE = 'candidatos';
const PHOTO_BUCKET = 'fotos-candidatos';
const MAX_PHOTO_BYTES = 5 * 1024 * 1024;
const SAVE_BATCH_SIZE = 100;
const HISTORICAL_ELECTION_YEARS = [2024, 2022, 2020, 2018, 2016];
const resolveElectionYear = (value, fallback = 2026) => {
  const parsed = Number(value);
  return Number.isInteger(parsed) && parsed >= 2000 ? parsed : fallback;
};
const DEFAULT_ELECTION_YEAR = resolveElectionYear(process.env.ELEICAO_ANO, 2026);

function getOfficialPhotosUrl(year = DEFAULT_ELECTION_YEAR) {
  return `https://cdn.tse.jus.br/estatistica/sead/eleicoes/eleicoes${year}/fotos/foto_cand${year}_ES_div.zip`;
}

function getOfficialCandidatesUrl(year = DEFAULT_ELECTION_YEAR) {
  return `https://cdn.tse.jus.br/estatistica/sead/odsele/consulta_cand/consulta_cand_${year}.zip`;
}

function cleanText(value) {
  return String(value ?? '').trim();
}

function splitCSVLine(line, delimiter) {
  const result = [];
  let current = '';
  let inQuotes = false;

  for (let i = 0; i < line.length; i += 1) {
    const char = line[i];

    if (char === '"') {
      if (inQuotes && line[i + 1] === '"') {
        current += '"';
        i += 1;
      } else {
        inQuotes = !inQuotes;
      }
      continue;
    }

    if (char === delimiter && !inQuotes) {
      result.push(current);
      current = '';
      continue;
    }

    current += char;
  }

  result.push(current);
  return result;
}

function parseCSV(text) {
  const lines = text.split(/\r?\n/).filter((line) => line.trim() !== '');
  if (lines.length < 2) return [];

  const delimiter = (lines[0].match(/;/g) || []).length > (lines[0].match(/,/g) || []).length ? ';' : ',';
  const headers = splitCSVLine(lines[0], delimiter).map((header) => header.replace(/^\uFEFF/, '').trim().toLowerCase());

  return lines.slice(1).map((line) => {
    const values = splitCSVLine(line, delimiter);
    return Object.fromEntries(headers.map((header, index) => [header, cleanText(values[index])]));
  });
}

function readInput(filePath) {
  const buffer = fs.readFileSync(filePath);
  let raw;

  try {
    raw = new TextDecoder('utf-8', { fatal: true }).decode(buffer);
  } catch {
    raw = iconv.decode(buffer, 'windows-1252');
  }

  if (filePath.toLowerCase().endsWith('.json')) {
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed)) return parsed;
    if (Array.isArray(parsed.candidatos)) return parsed.candidatos;
    if (Array.isArray(parsed.resultados)) return parsed.resultados;
    return [parsed];
  }

  if (filePath.toLowerCase().endsWith('.csv')) return parseCSV(raw);

  throw new Error('Formato não suportado. Use um CSV ou JSON de fonte autorizada.');
}

function normalizeCandidate(record) {
  const raw = Object.fromEntries(
    Object.entries(record || {}).map(([key, value]) => [key.toLowerCase(), value])
  );
  const idTse = cleanText(raw.sq_candidato || raw.id_tse || raw.id);
  const nome = cleanText(raw.nm_candidato || raw.nomecompleto || raw.nome || raw.name);
  const nomeUrna = cleanText(raw.nm_urna || raw.nm_urna_candidato || raw.nomeurna || raw.nome_urna || raw.nome_de_urna || nome);
  const partido = cleanText(raw.sg_partido || raw.partido || raw.party);
  const cargo = cleanText(raw.ds_cargo || raw.cargo);
  const numero = cleanText(raw.nr_candidato || raw.numero_candidato || raw.numero);
  const ano = Number(raw.ano_eleicao || raw.ano || raw.anoselecao);
  const estado = cleanText(raw.sg_uf || raw.estado || raw.uf || raw.ufcandidatura).toUpperCase();
  const birthDate = cleanText(raw.dt_nascimento || raw.data_nascimento);
  const birthplace = [
    cleanText(raw.nm_municipio_nascimento || raw.naturalidade),
    cleanText(raw.sg_uf_nascimento)
  ].filter(Boolean).join(' / ');
  const imagemUrl = cleanText(
    raw.url_foto ||
    raw.urlfoto ||
    raw.foto_url ||
    raw.fotourl ||
    raw.imagem_url ||
    raw.image_url ||
    raw.photo_url ||
    raw.urlfoto1 ||
    raw.foto
  );

  if (!idTse || !nome || !nomeUrna || !partido || !cargo || !numero || !Number.isInteger(ano) || !estado) {
    return null;
  }

  return {
    id_tse: idTse,
    nome,
    nome_urna: nomeUrna,
    partido,
    cargo,
    numero,
    ano,
    municipio: cleanText(raw.nm_ue || raw.municipio || raw.cidade || raw.localcandidatura) || null,
    estado,
    situacao: cleanText(raw.ds_sit_tot_turno || raw.situacao || raw.status) || null,
    imagem_url: imagemUrl || null,
    data_nascimento: /^\d{4}-\d{2}-\d{2}$/.test(birthDate)
      ? birthDate
      : /^(\d{2})\/(\d{2})\/(\d{4})$/.test(birthDate)
        ? birthDate.replace(/^(\d{2})\/(\d{2})\/(\d{4})$/, '$3-$2-$1')
        : null,
    naturalidade: birthplace || null,
    atividade_profissional: cleanText(raw.ds_ocupacao || raw.atividade_profissional) || null,
    cargos_anteriores: [],
    patrimonio_declarado: [],
    fonte: cleanText(raw.fonte) || 'importacao-autorizada',
    atualizado_em: new Date().toISOString()
  };
}

function filterEs(records) {
  return records
    .map(normalizeCandidate)
    .filter((candidate) => candidate && candidate.estado === 'ES');
}

async function saveToSupabase(records) {
  if (!process.env.SUPABASE_URL || !process.env.SUPABASE_SERVICE_ROLE_KEY) {
    throw new Error('Variáveis do Supabase ausentes. Verifique env/supabase.env.');
  }

  const uniqueRecords = [...new Map(records.map((record) => [record.id_tse, record])).values()];
  if (uniqueRecords.length < records.length) {
    console.log(`Registros duplicados por id_tse ignorados: ${records.length - uniqueRecords.length}.`);
  }
  if (uniqueRecords.length === 0) return 0;

  const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);
  const imageRecords = uniqueRecords.filter((record) => record.imagem_url);
  const photosToUpload = imageRecords.filter((record) => isOfficialPhotoUrl(record.imagem_url));
  if (photosToUpload.length > 0) await ensurePhotoBucket(supabase);

  let photosUploaded = 0;
  const totalBatches = Math.ceil(uniqueRecords.length / SAVE_BATCH_SIZE);
  for (let index = 0; index < uniqueRecords.length; index += SAVE_BATCH_SIZE) {
    const batch = uniqueRecords.slice(index, index + SAVE_BATCH_SIZE);
    const ids = batch.map((record) => record.id_tse);
    const { data: existing, error: existingError } = await supabase
      .from(SUPABASE_TABLE)
      .select('id_tse, imagem_url')
      .in('id_tse', ids);

    if (existingError) throw existingError;
    const existingImages = new Map((existing || []).map((record) => [record.id_tse, record.imagem_url]));
    const savedBatch = [];

    for (const record of batch) {
      const candidate = { ...record };
      if (candidate.imagem_url) {
        const photoUrl = new URL(candidate.imagem_url);
        if (isOfficialPhotoUrl(candidate.imagem_url)) {
          candidate.imagem_url = await uploadCandidatePhoto(supabase, candidate, photoUrl);
          photosUploaded += 1;
        } else if (!isStoredPhotoUrl(candidate.imagem_url)) {
          throw new Error(`URL de foto não pertence ao domínio oficial do TSE (candidato ${candidate.id_tse}).`);
        }
      } else {
        candidate.imagem_url = existingImages.get(candidate.id_tse) || null;
      }
      savedBatch.push(candidate);
    }

    const { error } = await supabase
      .from(SUPABASE_TABLE)
      .upsert(savedBatch, { onConflict: 'id_tse' });

    if (error) throw error;
    const savedCount = Math.min(index + batch.length, uniqueRecords.length);
    console.log(`Lote ${Math.floor(index / SAVE_BATCH_SIZE) + 1}/${totalBatches} importado (${savedCount}/${uniqueRecords.length} candidatos).`);
  }

  if (photosUploaded > 0) console.log(`Fotos oficiais armazenadas no Supabase Storage: ${photosUploaded}`);
  return uniqueRecords.length;
}

async function downloadOfficialCandidatesArchive(archivePath, year) {
  const response = await fetch(getOfficialCandidatesUrl(year), {
    signal: AbortSignal.timeout(10 * 60 * 1000)
  });
  if (!response.ok) throw new Error(`TSE retornou HTTP ${response.status} ao baixar os candidatos de ${year}.`);
  if (!response.body) throw new Error('TSE não retornou o conteúdo do arquivo de candidatos.');

  await pipeline(Readable.fromWeb(response.body), fs.createWriteStream(archivePath));
}

async function processZipCsvEntry(zipFile, csvEntry, onRecord) {
  const csvStream = await new Promise((resolve, reject) => {
    zipFile.openReadStream(csvEntry, (error, stream) => {
      if (error) reject(error);
      else resolve(stream);
    });
  });
  const lines = readline.createInterface({
    input: csvStream.pipe(iconv.decodeStream('windows-1252')),
    crlfDelay: Infinity
  });

  let headers;
  let delimiter;
  for await (const line of lines) {
    if (!headers) {
      delimiter = (line.match(/;/g) || []).length > (line.match(/,/g) || []).length ? ';' : ',';
      headers = splitCSVLine(line, delimiter)
        .map((header) => header.replace(/^\uFEFF/, '').trim().toLowerCase());
      continue;
    }

    const values = splitCSVLine(line, delimiter);
    await onRecord(Object.fromEntries(headers.map((header, index) => [header, cleanText(values[index])])));
  }

  return headers || [];
}

async function importOfficialCandidates(year = DEFAULT_ELECTION_YEAR) {
  if (!process.env.SUPABASE_URL || !process.env.SUPABASE_SERVICE_ROLE_KEY) {
    throw new Error('Variáveis do Supabase ausentes. Verifique env/supabase.env.');
  }

  const temporaryDirectory = fs.mkdtempSync(path.join(os.tmpdir(), 'candidatos-tse-'));
  const archivePath = path.join(temporaryDirectory, `candidatos-${year}.zip`);
  const assetsArchivePath = path.join(temporaryDirectory, `bens-candidatos-${year}.zip`);
  let zipFile;
  let assetsZipFile;

  try {
    console.log(`Baixando o arquivo oficial de candidatos do TSE (${year})...`);
    await downloadOfficialCandidatesArchive(archivePath, year);
    zipFile = await openZipArchive(archivePath);
    const entries = await readZipEntries(zipFile);
    const csvEntry = entries.find((entry) =>
      path.posix.basename(entry.fileName).toLowerCase() === `consulta_cand_${year}_es.csv`
    );
    if (!csvEntry) throw new Error(`O arquivo oficial do TSE não contém a lista de candidatos do ES de ${year}.`);

    const records = [];
    const candidatesByCpf = new Map();
    const headers = await processZipCsvEntry(zipFile, csvEntry, async (raw) => {
      const candidate = normalizeCandidate(raw);
      if (candidate && candidate.estado === 'ES' && candidate.ano === year) {
        candidate.imagem_url = null;
        records.push(candidate);
        const cpf = cleanText(raw.nr_cpf_candidato).replace(/\D/g, '');
        if (cpf) {
          const matchingCandidates = candidatesByCpf.get(cpf) || [];
          matchingCandidates.push(candidate);
          candidatesByCpf.set(cpf, matchingCandidates);
        }
      }
    });
    const requiredHeaders = ['sq_candidato', 'nm_candidato', 'sg_partido', 'ds_cargo', 'nr_candidato', 'ano_eleicao', 'sg_uf'];
    const missingHeaders = requiredHeaders.filter((header) => !headers.includes(header));
    if (missingHeaders.length > 0) {
      throw new Error(`Formato inesperado no arquivo oficial do TSE; colunas ausentes: ${missingHeaders.join(', ')}.`);
    }

    if (records.length === 0) throw new Error(`O arquivo oficial não contém candidatos válidos do ES de ${year}; banco não alterado.`);

    if (!headers.includes('nr_cpf_candidato')) {
      throw new Error('O arquivo oficial não permite relacionar candidaturas anteriores; banco não alterado.');
    }

    for (const previousYear of HISTORICAL_ELECTION_YEARS) {
      const historyArchivePath = path.join(temporaryDirectory, `candidatos-historicos-${previousYear}.zip`);
      await downloadOfficialCandidatesArchive(historyArchivePath, previousYear);
      const historyZip = await openZipArchive(historyArchivePath);
      try {
        const historyEntries = await readZipEntries(historyZip);
        const historyEntry = historyEntries.find((entry) =>
          path.posix.basename(entry.fileName).toLowerCase() === `consulta_cand_${previousYear}_es.csv`
        );
        if (!historyEntry) {
          throw new Error(`O arquivo oficial do TSE não contém candidaturas do ES de ${previousYear}.`);
        }

        const historyHeaders = await processZipCsvEntry(historyZip, historyEntry, async (raw) => {
          const cpf = cleanText(raw.nr_cpf_candidato).replace(/\D/g, '');
          const matchingCandidates = cpf && candidatesByCpf.get(cpf);
          if (!matchingCandidates || cleanText(raw.sg_uf).toUpperCase() !== 'ES') return;

          const previousCandidacy = {
            ano: Number(raw.ano_eleicao) || previousYear,
            cargo: cleanText(raw.ds_cargo) || null,
            partido: cleanText(raw.sg_partido) || null,
            municipio: cleanText(raw.nm_ue) || null,
            situacao: cleanText(raw.ds_sit_tot_turno) || cleanText(raw.ds_situacao_candidatura) || null
          };
          const candidacyKey = JSON.stringify(previousCandidacy);
          for (const candidate of matchingCandidates) {
            if (!candidate.cargos_anteriores.some((item) => JSON.stringify(item) === candidacyKey)) {
              candidate.cargos_anteriores.push(previousCandidacy);
            }
          }
        });
        const requiredHistoryHeaders = ['nr_cpf_candidato', 'sg_uf', 'ds_cargo'];
        const missingHistoryHeaders = requiredHistoryHeaders.filter((header) => !historyHeaders.includes(header));
        if (missingHistoryHeaders.length > 0) {
          throw new Error(`Formato inesperado no arquivo do TSE de ${previousYear}; colunas ausentes: ${missingHistoryHeaders.join(', ')}.`);
        }
      } finally {
        historyZip.close();
      }
    }
    candidatesByCpf.clear();
    for (const candidate of records) {
      candidate.cargos_anteriores.sort((first, second) => second.ano - first.ano);
    }

    const candidateById = new Map(records.map((candidate) => [candidate.id_tse, candidate]));
    const assetsResponse = await fetch(`https://cdn.tse.jus.br/estatistica/sead/odsele/bem_candidato/bem_candidato_${year}.zip`, {
      signal: AbortSignal.timeout(10 * 60 * 1000)
    });
    if (!assetsResponse.ok) throw new Error(`TSE retornou HTTP ${assetsResponse.status} ao baixar os bens declarados de ${year}.`);
    if (!assetsResponse.body) throw new Error('TSE não retornou o conteúdo dos bens declarados.');
    await pipeline(Readable.fromWeb(assetsResponse.body), fs.createWriteStream(assetsArchivePath));
    assetsZipFile = await openZipArchive(assetsArchivePath);
    const assetsEntries = await readZipEntries(assetsZipFile);
    const assetsEntry = assetsEntries.find((entry) =>
      path.posix.basename(entry.fileName).toLowerCase() === `bem_candidato_${year}_es.csv`
    );
    if (!assetsEntry) throw new Error(`O arquivo oficial de bens não contém os dados do ES de ${year}.`);

    const assetHeaders = await processZipCsvEntry(assetsZipFile, assetsEntry, async (raw) => {
      const candidate = candidateById.get(cleanText(raw.sq_candidato));
      if (!candidate) return;
      const rawValue = cleanText(raw.vr_bem_candidato);
      const value = Number(rawValue.includes(',')
        ? rawValue.replace(/\./g, '').replace(',', '.')
        : rawValue);
      candidate.patrimonio_declarado.push({
        tipo: cleanText(raw.ds_tipo_bem_candidato) || null,
        descricao: cleanText(raw.ds_bem_candidato) || null,
        valor: Number.isFinite(value) ? value : null
      });
    });
    const requiredAssetHeaders = ['sq_candidato', 'ds_bem_candidato', 'vr_bem_candidato'];
    const missingAssetHeaders = requiredAssetHeaders.filter((header) => !assetHeaders.includes(header));
    if (missingAssetHeaders.length > 0) {
      throw new Error(`Formato inesperado no arquivo de bens do TSE; colunas ausentes: ${missingAssetHeaders.join(', ')}.`);
    }

    const savedCount = await saveToSupabase(records);
    console.log(`Importação oficial do TSE concluída: ${savedCount} candidatos de ${year}.`);
    return savedCount;
  } finally {
    if (zipFile) zipFile.close();
    if (assetsZipFile) assetsZipFile.close();
    fs.rmSync(temporaryDirectory, { recursive: true, force: true });
  }
}

async function deleteCandidatesFromOtherYears(year = DEFAULT_ELECTION_YEAR) {
  if (!process.env.SUPABASE_URL || !process.env.SUPABASE_SERVICE_ROLE_KEY) {
    throw new Error('Variáveis do Supabase ausentes. Verifique env/supabase.env.');
  }

  const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);
  let deletedCount = 0;
  while (true) {
    const { data, error } = await supabase
      .from(SUPABASE_TABLE)
      .select('id_tse')
      .neq('ano', year)
      .limit(SAVE_BATCH_SIZE);

    if (error) throw error;
    const ids = (data || []).map((candidate) => candidate.id_tse);
    if (ids.length === 0) break;

    const { error: deleteError } = await supabase
      .from(SUPABASE_TABLE)
      .delete()
      .in('id_tse', ids);
    if (deleteError) throw deleteError;

    deletedCount += ids.length;
  }

  if (deletedCount > 0) console.log(`Candidatos de outros anos removidos do Supabase: ${deletedCount}.`);
  return deletedCount;
}

function isOfficialPhotoUrl(value) {
  try {
    const url = new URL(value);
    return url.protocol === 'https:' && url.hostname === 'divulgacandcontas.tse.jus.br';
  } catch {
    return false;
  }
}

function isStoredPhotoUrl(value) {
  try {
    const url = new URL(value);
    const supabaseHost = new URL(process.env.SUPABASE_URL).hostname;
    return url.protocol === 'https:'
      && url.hostname === supabaseHost
      && url.pathname.startsWith(`/storage/v1/object/public/${PHOTO_BUCKET}/`);
  } catch {
    return false;
  }
}

async function ensurePhotoBucket(supabase) {
  const { data: buckets, error: listError } = await supabase.storage.listBuckets();
  if (listError) throw listError;

  const bucket = (buckets || []).find((item) => item.name === PHOTO_BUCKET);
  if (bucket) {
    if (!bucket.public) throw new Error(`O bucket "${PHOTO_BUCKET}" existe, mas não é público. Ajuste-o no Supabase Storage.`);
    return;
  }

  const { error } = await supabase.storage.createBucket(PHOTO_BUCKET, {
    public: true,
    fileSizeLimit: MAX_PHOTO_BYTES,
    allowedMimeTypes: ['image/jpeg', 'image/png', 'image/webp']
  });
  if (error) throw error;
}

async function uploadCandidatePhoto(supabase, candidate, photoUrl) {
  const response = await fetch(photoUrl, {
    headers: { Accept: 'image/jpeg, image/png, image/webp' },
    redirect: 'error',
    signal: AbortSignal.timeout(20000)
  });
  if (!response.ok) throw new Error(`TSE retornou HTTP ${response.status} para a foto do candidato ${candidate.id_tse}.`);

  const contentType = (response.headers.get('content-type') || '').split(';')[0].toLowerCase();
  const extensions = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp' };
  const extension = extensions[contentType];
  if (!extension) throw new Error(`Formato de foto não suportado para o candidato ${candidate.id_tse}: ${contentType || 'desconhecido'}.`);

  const declaredSize = Number(response.headers.get('content-length'));
  if (declaredSize > MAX_PHOTO_BYTES) throw new Error(`Foto do candidato ${candidate.id_tse} excede 5 MB.`);
  const image = Buffer.from(await response.arrayBuffer());
  if (image.length === 0 || image.length > MAX_PHOTO_BYTES) {
    throw new Error(`Tamanho inválido da foto do candidato ${candidate.id_tse}.`);
  }

  const objectPath = `${candidate.ano}/${candidate.id_tse}.${extension}`;
  const { error } = await supabase.storage
    .from(PHOTO_BUCKET)
    .upload(objectPath, image, { contentType, upsert: true, cacheControl: '31536000' });
  if (error) throw error;

  return supabase.storage.from(PHOTO_BUCKET).getPublicUrl(objectPath).data.publicUrl;
}

async function downloadOfficialPhotosArchive(archivePath, year = DEFAULT_ELECTION_YEAR) {
  const response = await fetch(getOfficialPhotosUrl(year), {
    signal: AbortSignal.timeout(10 * 60 * 1000)
  });
  if (!response.ok) throw new Error(`TSE retornou HTTP ${response.status} ao baixar o pacote de fotos.`);
  if (!response.body) throw new Error('TSE não retornou o conteúdo do pacote de fotos.');

  await pipeline(Readable.fromWeb(response.body), fs.createWriteStream(archivePath));
}

function openZipArchive(archivePath) {
  return new Promise((resolve, reject) => {
    yauzl.open(archivePath, { lazyEntries: true, autoClose: false }, (error, zipFile) => {
      if (error) reject(error);
      else resolve(zipFile);
    });
  });
}

function readZipEntries(zipFile) {
  return new Promise((resolve, reject) => {
    const entries = [];
    const onError = (error) => {
      zipFile.removeListener('end', onEnd);
      reject(error);
    };
    const onEnd = () => {
      zipFile.removeListener('error', onError);
      resolve(entries);
    };

    zipFile.on('error', onError);
    zipFile.on('end', onEnd);
    zipFile.on('entry', (entry) => {
      entries.push(entry);
      zipFile.readEntry();
    });
    zipFile.readEntry();
  });
}

function readZipEntry(zipFile, entry) {
  if (entry.uncompressedSize > MAX_PHOTO_BYTES) {
    return Promise.reject(new Error(`Foto excede 5 MB: ${entry.fileName}`));
  }

  return new Promise((resolve, reject) => {
    zipFile.openReadStream(entry, (error, stream) => {
      if (error) {
        reject(error);
        return;
      }

      const chunks = [];
      let size = 0;
      stream.on('data', (chunk) => {
        size += chunk.length;
        if (size > MAX_PHOTO_BYTES) {
          stream.destroy(new Error(`Foto excede 5 MB: ${entry.fileName}`));
          return;
        }
        chunks.push(chunk);
      });
      stream.on('error', reject);
      stream.on('end', () => resolve(Buffer.concat(chunks, size)));
    });
  });
}

async function loadCandidatesForPhotos(supabase, year = DEFAULT_ELECTION_YEAR) {
  const candidates = [];
  const pageSize = 1000;
  let offset = 0;

  while (true) {
    const { data, error } = await supabase
      .from(SUPABASE_TABLE)
      .select('id_tse, nome, nome_urna, partido, cargo, numero, ano, municipio, estado, situacao, imagem_url, fonte, atualizado_em')
      .eq('estado', 'ES')
      .eq('ano', year)
      .range(offset, offset + pageSize - 1);

    if (error) throw error;
    candidates.push(...(data || []));
    if (!data || data.length < pageSize) break;
    offset += pageSize;
  }

  return candidates;
}

async function loadStoredPhotoNames(supabase, year = DEFAULT_ELECTION_YEAR) {
  const photoNames = new Set();
  const pageSize = 1000;
  let offset = 0;

  while (true) {
    const { data, error } = await supabase.storage
      .from(PHOTO_BUCKET)
      .list(String(year), { limit: pageSize, offset });
    if (error) throw error;

    for (const photo of data || []) photoNames.add(photo.name);
    if (!data || data.length < pageSize) break;
    offset += pageSize;
  }

  return photoNames;
}

function isTransientStorageError(error) {
  const status = Number(error.statusCode || error.status);
  return [408, 425, 429, 500, 502, 503, 504].includes(status)
    || /bad gateway|gateway timeout|temporarily unavailable|fetch failed|network|timeout/i.test(error.message || '');
}

async function uploadPhotoWithRetry(supabase, objectPath, image) {
  let lastError;
  for (let attempt = 1; attempt <= 4; attempt += 1) {
    try {
      const { error } = await supabase.storage
        .from(PHOTO_BUCKET)
        .upload(objectPath, image, { contentType: 'image/jpeg', upsert: true, cacheControl: '31536000' });
      if (!error) return;
      if (!isTransientStorageError(error) || attempt === 4) throw error;
      lastError = error;
    } catch (error) {
      if (!isTransientStorageError(error) || attempt === 4) throw error;
      lastError = error;
    }

    console.warn(`Falha temporária ao enviar ${objectPath}; nova tentativa ${attempt + 1}/4.`);
    await new Promise((resolve) => setTimeout(resolve, 500 * (2 ** attempt)));
  }

  throw lastError;
}

async function importOfficialCandidatePhotos(year = DEFAULT_ELECTION_YEAR) {
  if (!process.env.SUPABASE_URL || !process.env.SUPABASE_SERVICE_ROLE_KEY) {
    throw new Error('Variáveis do Supabase ausentes. Verifique env/supabase.env.');
  }

  const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);
  const candidates = await loadCandidatesForPhotos(supabase, year);
  if (candidates.length === 0) throw new Error(`Nenhum candidato de ${year} foi encontrado no Supabase.`);
  await ensurePhotoBucket(supabase);
  const storedPhotoNames = await loadStoredPhotoNames(supabase, year);

  const candidatesById = new Map(candidates.map((candidate) => [candidate.id_tse, candidate]));
  const temporaryDirectory = fs.mkdtempSync(path.join(os.tmpdir(), 'fotos-candidatos-tse-'));
  const archivePath = path.join(temporaryDirectory, `fotos-es-${year}.zip`);
  let zipFile;

  try {
    console.log(`Baixando o pacote oficial de fotos do TSE (Espírito Santo, ${year})...`);
    await downloadOfficialPhotosArchive(archivePath, year);
    zipFile = await openZipArchive(archivePath);
    const entries = await readZipEntries(zipFile);
    const photos = entries.flatMap((entry) => {
      const match = /^FES(\d+)_div\.(jpe?g)$/i.exec(path.posix.basename(entry.fileName));
      const candidate = match && candidatesById.get(match[1]);
      return candidate ? [{ entry, candidate, extension: match[2].toLowerCase() }] : [];
    });

    if (photos.length === 0) throw new Error('O pacote do TSE não contém fotos correspondentes aos candidatos do Supabase.');

    let photosUploaded = 0;
    let photosAlreadyAvailable = 0;
    let photosProcessed = 0;
    let nextPhoto = 0;
    let firstError = null;
    const uploadWorker = async () => {
      while (!firstError) {
        const photo = photos[nextPhoto];
        nextPhoto += 1;
        if (!photo) return;

        try {
          const extension = photo.extension === 'jpeg' ? 'jpg' : photo.extension;
          const fileName = `${photo.candidate.id_tse}.${extension}`;
          if (storedPhotoNames.has(fileName)) {
            photosAlreadyAvailable += 1;
            photosProcessed += 1;
            if (photosProcessed % 500 === 0) console.log(`Fotos prontas: ${photosProcessed}/${photos.length}`);
            continue;
          }

          const image = await readZipEntry(zipFile, photo.entry);
          if (image.length === 0) throw new Error(`Foto vazia no pacote do TSE: ${photo.entry.fileName}`);
          const objectPath = `${photo.candidate.ano}/${fileName}`;
          await uploadPhotoWithRetry(supabase, objectPath, image);

          photosUploaded += 1;
          photosProcessed += 1;
          storedPhotoNames.add(fileName);
          if (photosProcessed % 500 === 0) console.log(`Fotos prontas: ${photosProcessed}/${photos.length}`);
        } catch (error) {
          firstError = error;
        }
      }
    };

    await Promise.all(Array.from({ length: 6 }, () => uploadWorker()));
    if (firstError) throw firstError;

    const updatedCandidates = photos.map(({ candidate, extension }) => {
      const fileExtension = extension === 'jpeg' ? 'jpg' : extension;
      const objectPath = `${candidate.ano}/${candidate.id_tse}.${fileExtension}`;
      return {
        ...candidate,
        imagem_url: supabase.storage.from(PHOTO_BUCKET).getPublicUrl(objectPath).data.publicUrl
      };
    });

    for (let index = 0; index < updatedCandidates.length; index += 500) {
      const { error } = await supabase
        .from(SUPABASE_TABLE)
        .upsert(updatedCandidates.slice(index, index + 500), { onConflict: 'id_tse' });
      if (error) throw error;
    }

    console.log(`Fotos oficiais do TSE prontas: ${photosUploaded + photosAlreadyAvailable} de ${candidates.length} candidatos (${photosUploaded} novas, ${photosAlreadyAvailable} já existentes).`);
    console.log(`URLs das fotos salvas na coluna ${SUPABASE_TABLE}.imagem_url: ${updatedCandidates.length}.`);
    return photosUploaded;
  } finally {
    if (zipFile) zipFile.close();
    fs.rmSync(temporaryDirectory, { recursive: true, force: true });
  }
}

function parseArgs(argv) {
  const args = { input: null, output: null, save: false, photos: false };

  for (let index = 0; index < argv.length; index += 1) {
    if (argv[index] === '--input') args.input = argv[++index];
    else if (argv[index] === '--output') args.output = argv[++index];
    else if (argv[index] === '--save') args.save = true;
    else if (argv[index] === '--photos') args.photos = true;
    else if (!argv[index].startsWith('--') && !args.input) args.input = argv[index];
  }

  return args;
}

async function main() {
  const { input, output, save, photos } = parseArgs(process.argv.slice(2));
  if (photos) return importOfficialCandidatePhotos();
  if (!input) throw new Error('Uso: node src/candidatos.js --input <arquivo.csv|arquivo.json> [--output arquivo.json] [--save]');

  const inputPath = path.resolve(input);
  if (!fs.existsSync(inputPath)) throw new Error(`Arquivo não encontrado: ${inputPath}`);

  const records = filterEs(readInput(inputPath));
  const result = { total: records.length, registros: records };

  if (output) {
    const outputPath = path.resolve(output);
    fs.mkdirSync(path.dirname(outputPath), { recursive: true });
    fs.writeFileSync(outputPath, JSON.stringify(result, null, 2), 'utf8');
    console.log(`Arquivo salvo em ${outputPath}`);
  }

  if (save) console.log(`Registros enviados para Supabase (${SUPABASE_TABLE}): ${await saveToSupabase(records)}`);
  console.log(JSON.stringify(result, null, 2));
}

if (require.main === module) {
  main().catch((error) => {
    console.error('Erro ao processar candidaturas:', error.message);
    process.exitCode = 1;
  });
}

module.exports = {
  parseCSV,
  readInput,
  normalizeCandidate,
  filterEs,
  saveToSupabase,
  importOfficialCandidates,
  deleteCandidatesFromOtherYears,
  importOfficialCandidatePhotos,
  PHOTO_BUCKET,
  main
};