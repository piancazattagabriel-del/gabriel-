alter table public.candidatos
  add column if not exists imagem_url text;
