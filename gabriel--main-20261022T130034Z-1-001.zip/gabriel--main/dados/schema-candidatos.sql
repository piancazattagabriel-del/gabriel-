create table if not exists public.candidatos (
  id_tse text primary key,
  nome text not null,
  nome_urna text not null,
  partido text not null,
  cargo text not null,
  numero text not null,
  ano integer not null,
  municipio text,
  estado text not null check (estado = 'ES'),
  situacao text,
  imagem_url text,
  data_nascimento date,
  naturalidade text,
  atividade_profissional text,
  cargos_anteriores jsonb not null default '[]'::jsonb,
  patrimonio_declarado jsonb not null default '[]'::jsonb,
  fonte text not null,
  atualizado_em timestamptz not null default now()
);

alter table public.candidatos
  add column if not exists imagem_url text;

alter table public.candidatos
  add column if not exists data_nascimento date,
  add column if not exists naturalidade text,
  add column if not exists atividade_profissional text,
  add column if not exists cargos_anteriores jsonb not null default '[]'::jsonb,
  add column if not exists patrimonio_declarado jsonb not null default '[]'::jsonb;

create index if not exists candidatos_es_busca_idx
  on public.candidatos (ano desc, cargo, nome_urna);

alter table public.candidatos enable row level security;

create table if not exists public.candidatos_importacoes (
  chave text primary key,
  atualizado_em timestamptz not null default now()
);

alter table public.candidatos_importacoes enable row level security;